export const FETCH_LAUNCHES ='FETCH_LAUNCHES';
export const FETCH_LAUNCHPADS ='FETCH_LAUNCHPADS';

function receiveLaunches(json)
{
    return{
        type: FETCH_LAUNCHES,
        json
    }
}

function fetchLaunchesJson()
{
    const url = `http://localhost:8001/launches`;
     return fetch(url)
    .then(response => response.json())
}

export function fetchLaunches()
{
    return function(disptach)
    {
        return fetchLaunchesJson()
        .then(json => disptach(receiveLaunches(json)))
        .catch(error => alert(error.message));
    } 
}

function receiveLaunchPads(json)
{
    return{
        type: FETCH_LAUNCHPADS,
        json
    }
}

function fetchLaunchPadsJson()
{
    const url = `http://localhost:8001/launchpads`;
     return fetch(url)
    .then(response => response.json())
}

export function fetchLaunchPads()
{
    return function(disptach)
    {
        return fetchLaunchPadsJson()
        .then(json => disptach(receiveLaunchPads(json)))
        .catch(error => alert(error.message));
    } 
}