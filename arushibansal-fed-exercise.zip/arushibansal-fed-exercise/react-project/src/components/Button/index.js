import Button, { TYPES } from './Button';

export { TYPES };
export default Button;
