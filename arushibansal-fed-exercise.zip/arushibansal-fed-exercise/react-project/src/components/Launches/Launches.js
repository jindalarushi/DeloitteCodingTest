import React from 'react';
import LaunchFilter from '../LaunchFilter';
import LaunchItem from '../LaunchItem';

import styles from './launches.module.scss';
import { connect } from 'react-redux';
import { fetchLaunches } from '../../actions';

/**
 * Launches component responsible for showing the filter component,
 * handling the fetching and filtering of the launch data and rendering
 * the launches that match the selected filters
 */

//let noOfMissions =''; 

class Launches extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      isLoading: false,
      error: null,
      launches: [],
      noOfMissions:'',
      filteredLaunches:[],
      isLoading:false,
      filter: {
        minYear: null,
        maxYear: null,
        keywords: '',
        launchPad: null,
      },
    };

  }

  handleFilterChange = filter => {
    this.setState({filter});
    
    
  };

  /**
   * Responsible for transforming the data from the launch and launchpad api's
   * into a usable and consistent format for the LaunchItem component
   */
  _launchDataTransform = (launchResp, launchPads) => 
  {
    if(launchPads.length >0 && launchResp != null)
    {
      let launchPad = launchPads.find(pad => launchResp.launch_site.site_id === pad.id);
      const resultObj = {
        rocketName: launchResp.rocket.rocket_name,
        payloadId: launchResp.payloads[0].payload_id,
        launchDate: launchResp.launch_date_local,
        launchSiteName: launchPad.full_name,
        flightNumber: launchResp.flight_number ,
        missionFailed: launchResp.launch_success,
        missionPatchLink: launchResp.links.mission_patch,
        redditCampaignLink: launchResp.links.reddit_campaign,
        redditLaunchLink: launchResp.links.reddit_launch,
        redditMediaLink: launchResp.links.reddit_media,  
        pressKitLink: launchResp.links.presskit,
        articleLink: launchResp.links.article_link,
        videoLink: launchResp.links.video_link
      };
      return resultObj;
    }
    else
    {
      return null;
    }
  };

  _filterlaunches =(item) =>
  {
         const {keywords, launchPad, minYear, maxYear} = this.state.filter;
         if(keywords != '')
        {
            if(`${item.flightNumber}`.includes(keywords) || 
           `${item.rocketName}`.toLowerCase().includes(keywords.toLowerCase()) || 
           `${item.payloadId}`.toLowerCase().includes(keywords.toLowerCase()))
            {  
               // do nothing
            }
            else
            {
               return false;
            }
        }
        if(launchPad != null)
        {
          if(launchPad.value != null)
          {
              if(`${item.launchSiteName}` === `${launchPad.value}`)
              {  
                // do nothing      
              }
             else
              {
                 return false;
              } 
          }
        }
        if(minYear != null)
        {
           if(minYear.value != null)
            {
                if(`${item.launchDate}`.substring(0,4) >= `${minYear.value}`)
                {  
                  // do nothing      
                }
                else
                {
                   return false;
                } 
            }
        }
        if(maxYear != null)
        {
            if(maxYear.value != null)
            {
               if(`${item.launchDate}`.substring(0,4) <= `${maxYear.value}`)
               {  
                  // do nothing      
               }
              else
              {
                return false;
              } 
            }
        }
    
    return true;
  
  }

  _renderLaunches = () => {


     this.state.launches = this.props.launches;
     const { launches } = this.state;
     const launchPadData = this.props.launchPads;

     const originalLaunches = launches
       .map(l => this._launchDataTransform(l, launchPadData));

     if(originalLaunches.indexOf(null) === -1)
     {
        this.state.isLoading = false;
        const filteredLaunches = originalLaunches.filter(item => this._filterlaunches(item));
        this.state.noOfMissions = Object.keys(filteredLaunches).length ;
        this.state.filteredLaunches = filteredLaunches;
     }
     else
     {
        this.state.isLoading = true;
     }
    
  };

  render() {
    return (
      <section className={`${styles.launches} layout-l`}>
        <LaunchFilter 
          onFilterChange={this.handleFilterChange} 
          launchPads={this.props.launchPads} 
          launchYears={this.props.launches}
        />
        {this._renderLaunches()}
        {
            this.state.isLoading ?
                <div className={styles.summary}>
                    <p>isLoading....</p>
                </div>
           :
                <div>
                    <div className={styles.summary}>
                        <p>Showing {this.state.noOfMissions} Missions</p> 
                    </div>
                    {this.state.filteredLaunches.map(l => <LaunchItem {...l} />)};
                </div>
        }
      </section>
    );
  }
}


function mapStateToProps(state)
{
    return { launches : state.fetchLaunches, launchPads: state.fetchLaunchPads}
}

export default connect(mapStateToProps, null)(Launches);
