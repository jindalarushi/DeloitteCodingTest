import React from 'react';
import PropTypes from 'prop-types';

import Select from '../Select';
import TextInput from '../TextInput';
import Button, { TYPES as BUTTON_TYPES } from '../Button';
import styles from './launch-filter.module.scss';

// Example static option value
// the real options will need to come from the api

/**
 * Launch filter holds the filter state and writes the changes to the filters
 * back up to the parent element on click of the apply button
 */
class LaunchFilter extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      keywords: '',
      launchPad: null,
      minYear: null,
      maxYear: null
        };
    
  }

  // some change handlers ready for you
  handleKeywordChange = value => {
    this.state.keywords = value;
    this.props.onFilterChange(this.state)
  };
  handleLaunchPadChange = launchPad => {
    this.state.launchPad = launchPad;
    this.props.onFilterChange(this.state);
  };
  handleMinYearChange = minYear => {
    this.state.minYear = minYear;
    if(this.state.maxYear != null)
    {
      if(this.state.maxYear.value < this.state.minYear.value)
      {
        alert('Invalid Date Range');
      }
    }
    this.props.onFilterChange(this.state);
  };
  handleMaxYearChange = maxYear => {
    this.state.maxYear = maxYear;
    if(this.state.minYear != null)
    {
      if(this.state.minYear.value > this.state.maxYear.value)
      {
        alert('Invalid Date Range');
      }
    }
    this.props.onFilterChange(this.state);
  };

  // handler for calling the filter update
  handleFilterUpdate = () => {
    this.props.onFilterChange(this.state);
  };

  render() {
    const { keywords, launchPad, minYear, maxYear } = this.state;
    
    const options = [{ value: null, label: 'Any' }];
    this.props.launchPads.map(launchPad =>
      {
        options.push({value:launchPad.full_name, label:launchPad.full_name});
      })

    const years = [];
    this.props.launchYears.map(launch =>
      {
        const year = `${launch.launch_date_local}`.substring(0, 4);
        years.push(year);
      })
    const distinctYears = [...new Set(years)];
    const yearOptions =[{value: null, label:'Any'}];
    distinctYears.map(year =>
      {
        yearOptions.push({value:year, label:year});
      })

    return (
      <section className={styles.launchFilter}>
        <TextInput
          placeholder="eg Falcon"
          label="Keyword"
          value={keywords}
          onChange={this.handleKeywordChange}
          uid="example-text-input"
        />
        <Select
          label="Launch Pad"
          value={launchPad}
          onChange={this.handleLaunchPadChange}
          options={options}
          uid="example-select"
        /> 
        <Select
          label="Min Year"
          value={minYear}
          onChange={this.handleMinYearChange}
          options={yearOptions}
          uid="example-select"
        />
        <Select
          label="Max Year"
          value={maxYear}
          onChange={this.handleMaxYearChange}
          options={yearOptions}
          uid="example-select"
        />
        <Button onClick={this.handleFilterUpdate} type={BUTTON_TYPES.PRIMARY}>
          Apply
        </Button>
      </section>
    );
  }
}

LaunchFilter.propTypes = {

  // used to let parent component know about changes
  // to the filters
  onFilterChange: PropTypes.func
}

LaunchFilter.defaultProps = {
  onFilterChange: () => {
  },
}

export default LaunchFilter;
