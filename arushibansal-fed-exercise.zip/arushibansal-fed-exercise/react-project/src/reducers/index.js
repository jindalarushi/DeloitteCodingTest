import { FETCH_LAUNCHES } from '../actions';
import { FETCH_LAUNCHPADS } from '../actions';
import {combineReducers} from 'redux';

function fetchLaunches(state=[], action)
{
    switch(action.type)
    {
        case FETCH_LAUNCHES:
            let launches = action.json;
            return launches;
        default:
            return state;
    }
}

function fetchLaunchPads(state=[], action)
{
    switch(action.type)
    {
        case FETCH_LAUNCHPADS:
            let launchPads = action.json;
            return launchPads;
        default:
            return state;
    }
}

const rootReducers = combineReducers(
    {
        fetchLaunches,
        fetchLaunchPads
    }
)

export default rootReducers;